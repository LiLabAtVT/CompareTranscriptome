require('igraph');require('Matrix')

generate_coupling_matrix=function(list_orthologs,N1,N2){
  orth_list1=list_orthologs[,1];orth_list2=list_orthologs[,2];
  O12=sparseMatrix(i=orth_list1,j=orth_list2,x=1,dims=c(N1,N2))
  d1=rowSums(O12);d2=colSums(O12)
  o1=d1[orth_list1];o2=d2[orth_list2]
  couple=sparseMatrix(i=orth_list1,j=orth_list2,x=(1/o1+1/o2)/2,dims=c(N1,N2))
  big_couple=rBind(
    cBind(Matrix(0,N1,N1,sparse=T),couple),
    cBind(Matrix:::t(couple),Matrix(0,N2,N2,sparse=T)))
  return(big_couple)}

get_energy=function(G1,G2,sigma1,sigma2,big_couple,kappa){
  mod1=modularity(G1,sigma1);K1=colSums(get.adjacency(G1));M1=sum(K1)/2;E1=-(2*M1*mod1)
  mod2=modularity(G2,sigma2);K2=colSums(get.adjacency(G2));M2=sum(K2)/2;E2=-(2*M2*mod2)
  N1=length(V(G1));N2=length(V(G2))
  A=big_couple[1:N1,(N1+1):(N2+N1)]
  ij=Matrix:::which(A!= 0, arr.ind=T);L=A[ij]
  O12=-sum(L[sigma1[ij[,1]]==sigma2[ij[,2]]]) 
  E=E1+E2+O12*kappa;return(E)}

OrthoClust2=function(Eg1,Eg2,list_orthologs,kappa,flag_debug=T){
  Eg1_names=Eg1;Eg2_names=Eg2;list_orthologs_names=list_orthologs
  gene_set1=unique(c(Eg1_names[,1],Eg1_names[,2],list_orthologs_names[,1]))
  gene_set2=unique(c(Eg2_names[,1],Eg2_names[,2],list_orthologs_names[,2]));
  Eg1=cbind(match(Eg1_names[,1],gene_set1),match(Eg1_names[,2],gene_set1))
  Eg2=cbind(match(Eg2_names[,1],gene_set2),match(Eg2_names[,2],gene_set2))
  list_orthologs=cbind(match(list_orthologs_names[,1],gene_set1),match(list_orthologs_names[,2],gene_set2))
  G1=graph.edgelist(as.matrix(rbind(Eg1,cbind(1:length(gene_set1),1:length(gene_set1)))),directed=F)
  A1=get.adjacency(G1);diag(A1)=0;A1=(A1>0)*1;N1=nrow(A1)
  G2=graph.edgelist(as.matrix(rbind(Eg2,cbind(1:length(gene_set2),1:length(gene_set2)))),directed=F)
  A2=get.adjacency(G2);diag(A2)=0;A2=(A2>0)*1;N2=nrow(A2)
  big_couple=generate_coupling_matrix(list_orthologs,N1,N2);
  
  N=N1+N2;q=N;sigma1=1:N1;sigma2=N1+(1:N2);gamma=1;Niter=0
  A1_array=vector('list',N1);for(i in 1:N1){A1_array[[i]]=which(A1[,i]==1)}
  A2_array=vector('list',N2);for(i in 1:N2){A2_array[[i]]=which(A2[,i]==1)}
  K1=colSums(A1);M1=sum(K1)/2;Ks1=rep(0,1,q)
  K2=colSums(A2);M2=sum(K2)/2;Ks2=rep(0,1,q);
  for(k in 1:q){Ks1[k]=sum(K1[sigma1==k]);Ks2[k]=sum(K2[sigma2==k])}#for each spin, find all nodes with the spin label, and sum their degrees
  
  gain=1;E_init=get_energy(G1,G2,sigma1,sigma2,big_couple,kappa);E=E_init;
  seq=sample.int(N)  
  while(gain==1){
    Cost=rep(0,1,N);gain=0;    
    for(j in 1:length(seq)){
      x=seq[j]
      if(x<=N1){spin=sigma1[x];neighbors_spin=sigma1[A1_array[[x]]];
                antiferro_delta=(Ks1-Ks1[spin])*K1[x]+K1[x]^2;#new-old;
                antiferro_delta[spin]=0;M=M1
      }else if(x>N1){
        spin=sigma2[x-N1];neighbors_spin=sigma2[A2_array[[x-N1]]];
        antiferro_delta=(Ks2-Ks2[spin])*K2[x-N1]+K2[x-N1]^2;#new-old;
        antiferro_delta[spin]=0;M=M2 }
      nq_hist=rep(0,1,q);#for(k in neighbors_spin) nq_hist[k]=nq_hist[k]+1
      for(k in unique(neighbors_spin)) nq_hist[k]=sum(neighbors_spin==k)
      neighbors_delta=(-nq_hist[spin]+nq_hist);#the change with respect to all possibilites...%new-old% to all spin value..indexed by spin value
      E_delta=-neighbors_delta+gamma*antiferro_delta/(2*M);#at the beginning, flipping the spin to values at other network cannot change E
      
      i_ortho=which(big_couple[x,]!=0)
      couple=big_couple[x,i_ortho];
      if(x<=N1){i_ortho=i_ortho-N1;sigma_tmp=sigma2;}else sigma_tmp=sigma1
      ortho_delta=matrix(0,q,length(i_ortho))
      if(length(i_ortho)>0){ 
        for(o in 1:length(i_ortho)){
          if(spin!=sigma_tmp[i_ortho[o]]){
            ortho_delta[sigma_tmp[i_ortho[o]],o]=couple[o];#deltaE chart is [0 0...1 0 0]', just means New-OLD, with OLD=0, and New=1 for a particular q
          }else{  ortho_delta[,o]=-couple[o];
                  ortho_delta[sigma_tmp[i_ortho[o]],o]=0;#deltaE chart is [-1 -1...0 -1 -1]'; OLD=1, New=1 for a particular q, others=0
          }
        }    
      }
      E_delta=E_delta-kappa*rowSums(ortho_delta)
      Cost[j]=min(E_delta);new_spin=which.min(E_delta)
      if(x<=N1){sigma1[x]=new_spin;Ks1[spin]=Ks1[spin]-K1[x];Ks1[new_spin]=Ks1[new_spin]+K1[x];
      }else{ sigma2[x-N1]=new_spin;Ks2[spin]=Ks2[spin]-K2[x-N1];Ks2[new_spin]=Ks2[new_spin]+K2[x-N1]}
    }
    
    Nco=sort(union(sigma1,sigma2));sigma1=match(sigma1,Nco);sigma2=match(sigma2,Nco)
    q=length(Nco);Ks1=Ks1[Nco];Ks2=Ks2[Nco];
    sigma=c(sigma1,sigma2)
    E=E+sum(Cost); if(sum(Cost)<0) gain=1
    if(flag_debug){sigma_tab=table(sigma)  #[Nco,~,S2]=unique(sigma);Sco=histc(S2,1:length(Nco));Nco2 = length(Sco(Sco>1));
                   print(paste('Iteration=',Niter,' - Energy=',round(E,2),',',length(Nco),' com(', sum(sigma_tab>1),')',sep=''))}
    Niter=Niter+1;
  }
  names(sigma1)=gene_set1;names(sigma2)=gene_set2;
  return(list(species1_clust=sigma1,species2_clust=sigma2))
}